# Orbit Social — Android / Google Play packaging starter

This is an Android Studio **source project** for packaging the existing Orbit Social web app as a Trusted Web Activity (TWA). It does not duplicate the website backend; it launches the deployed Orbit site in the user's supported browser engine. This is intentional so Google sign-in, posts, profile photos, AI moderation, account warnings, bans, and unbans continue to use the existing server-side app.

## Project status

- App id: `app.orbit.social`
- Display name: `Orbit Social`
- `compileSdk` / `targetSdk`: 36 (Android 16; current Google Play target for new phone apps as of October 2026)
- TWA wrapper dependency: Android Browser Helper `2.7.4`
- Web origin: `https://orbit-social-xnkowc.v2.appdeploy.ai/`
- Included: Android Studio project, custom Orbit icon (SVG and PNG), adaptive launcher/splash artwork, Gradle configuration, PWA manifest draft, and a Digital Asset Links template.
- Not included: compiled APK/AAB, signing keystore, final Digital Asset Links fingerprint, Google Play listing, or Play Console review approval.

## Build prerequisites

Use a Windows, macOS, or Linux computer with Android Studio installed, Java 17+, Android SDK Platform 36, and an internet connection so Gradle can download plugins/dependencies. This environment has Java but no Android SDK, Gradle installation, or working package-download network, so the source was validated but an APK/AAB could not be compiled or installed here.

## Build in Android Studio

1. Extract the ZIP and open the `orbit-social-android-project` folder in Android Studio.
2. Allow Gradle sync. If prompted, install Android SDK Platform 36 and the matching Build Tools.
3. Use **Build → Make Project** to verify compilation.
4. For a device test, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Install the debug APK on a test device and try Google sign-in, post creation, profile-picture changes, replies, moderation feedback, and the owner moderation path.
5. For Play, use **Build → Generate Signed Bundle / APK → Android App Bundle**. A parent/guardian who owns the Play Console account should manage the signing setup and Play upload. Choose Play App Signing when prompted and store any upload key securely. Never put keystore passwords or private signing files in source control.

Command-line alternative after Android Studio installs the SDK and Gradle environment:

```bash
gradle :app:assembleDebug
gradle :app:bundleRelease
```

The release bundle output is normally `app/build/outputs/bundle/release/app-release.aab`. It must be signed/configured before Play upload; an AAB is not directly installable like an APK.

## Important: website verification / full-screen TWA

Android's Trusted Web Activity uses Digital Asset Links to verify that the Android app and website belong together. Until that is configured, a TWA may fall back to a browser Custom Tab (so a browser bar can appear).

1. First deploy `website-updates/manifest.webmanifest` and the matching `index.html` link to the existing AppDeploy site. This AppDeploy account hit its daily deployment-credit limit during this task, so those site updates are **prepared here but not yet live**.
2. Build/sign the Android app and obtain the **SHA-256 certificate fingerprint for the Play App Signing certificate** from Play Console after enrollment. Do not use a random fingerprint or assume the upload-key and Play app-signing fingerprints match.
3. Replace the placeholder in `website-updates/.well-known/assetlinks.template.json` with that exact fingerprint, and publish it at `https://orbit-social-xnkowc.v2.appdeploy.ai/.well-known/assetlinks.json` (a later AppDeploy deployment is required).
4. Verify that URL returns the JSON directly with HTTP 200 and valid `application/json` before testing the TWA fullscreen handoff.

## Testing checklist

- [ ] Android Studio Gradle sync and compile succeed.
- [ ] Debug APK installs on an Android phone and opens Orbit.
- [ ] Google sign-in completes and returns to Orbit (the auth provider can behave differently in app/browser contexts, so this must be tested on-device).
- [ ] Publish a safe post and confirm the saved author picture renders.
- [ ] Upload/change a profile photo and confirm it persists after reopening.
- [ ] Safe reply is accepted; unsafe/uncertain content shows the AI moderation message and is not published.
- [ ] Owner tools: warning, 24-hour ban, permanent ban, unban; self-ban is rejected.
- [ ] Verify Digital Asset Links and test full-screen TWA behavior.
- [ ] Complete Play Console Data safety, privacy policy, content rating, target audience, UGC moderation/reporting/blocking requirements, store listing, and testing track.

## Google Play account note

Google requires a Play Console developer to be at least 18. A parent/guardian needs to own and operate the developer account and handle publishing. New personal developer accounts also have a required closed-test process before production access; follow the policy shown inside their Play Console.

## Logo assets

- `assets/OrbitSocial-AppIcon-512.png` — full-color 512×512 app icon.
- `assets/OrbitSocial-Logo.svg` — editable vector logo with purple orbital-star mark.
- `assets/OrbitSocial-Logo-Transparent.png` — transparent logo mark for use over other backgrounds.
- `website-updates/orbit-logo.svg` and `website-updates/orbit-icon-512.png` — web assets staged for a later website update.
