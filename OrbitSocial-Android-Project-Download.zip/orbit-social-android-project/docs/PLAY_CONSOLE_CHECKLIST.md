# Before submitting Orbit Social to Google Play

This project is a packaging starter. It has **not** been reviewed or approved by Google Play.

## Must-complete technical steps

- Deploy the PWA manifest link and manifest to the live AppDeploy site.
- Build and install a debug APK on a real device.
- Test sign-in end-to-end; test post creation, profile-picture upload, replies, AI moderation, warnings, bans, and unbans.
- Build a signed AAB with a release upload key managed by the adult responsible for release.
- After enrolling in Play App Signing, copy the Play **app-signing** certificate SHA-256 into `website-updates/.well-known/assetlinks.template.json` and publish it at the required `/.well-known/assetlinks.json` URL.
- Check Digital Asset Links from the real public URL and verify the TWA opens fullscreen.
- Prepare privacy policy and Data safety form. Document all data the web app collects and how it is used.
- Complete app access instructions for reviewers if sign-in is required.

## User-generated content readiness

Orbit is a social app, so AI screening and moderator bans alone may not satisfy Play's UGC requirements. Google's policy calls for in-app ways to report users and content and to block users. Before production review, add and test report-post/report-user and block-user flows, provide community rules, and ensure ongoing moderation.

## Account and testing requirements

Google says Play Console developers must be at least 18. A parent/guardian must own the developer account and carry out account setup and publishing. New personal developer accounts are also subject to a closed-testing requirement (currently at least 12 opted-in testers continuously for 14 days before applying for production access); verify the requirement shown in the adult account's Play Console.
