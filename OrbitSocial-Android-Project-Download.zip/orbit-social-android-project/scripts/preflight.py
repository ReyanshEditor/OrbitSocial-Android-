#!/usr/bin/env python3
"""Static checks for Orbit Social's Android TWA project; does not compile Android code."""
from pathlib import Path
import json
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []


def check(condition, message):
    if not condition:
        errors.append(message)


def load_json(path):
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        errors.append(f"{path.relative_to(ROOT)} is not valid JSON: {exc}")
        return None

xml_files = list((ROOT / "app" / "src" / "main").rglob("*.xml"))
for path in xml_files:
    try:
        ET.parse(path)
    except Exception as exc:
        errors.append(f"{path.relative_to(ROOT)} is not well-formed XML: {exc}")

app_gradle = (ROOT / "app" / "build.gradle.kts").read_text()
manifest = (ROOT / "app" / "src" / "main" / "AndroidManifest.xml").read_text()
check('compileSdk = 36' in app_gradle, "compileSdk is not 36")
check('targetSdk = 36' in app_gradle, "targetSdk is not 36")
check('applicationId = "app.orbit.social"' in app_gradle, "unexpected/missing applicationId")
check("androidbrowserhelper:androidbrowserhelper:2.7.4" in app_gradle, "TWA dependency missing")
check("com.google.androidbrowserhelper.trusted.LauncherActivity" in manifest, "TWA launcher missing")
check('https://orbit-social-xnkowc.v2.appdeploy.ai/' in (ROOT / "app" / "src" / "main" / "res" / "values" / "strings.xml").read_text(), "launch URL doesn't match current site")

web_manifest = load_json(ROOT / "website-updates" / "manifest.webmanifest")
assetlinks = load_json(ROOT / "website-updates" / ".well-known" / "assetlinks.template.json")
check(bool(web_manifest and web_manifest.get("display") == "standalone"), "web manifest must use standalone display")
check(bool(web_manifest and any(icon.get("src") == "/orbit-logo.svg" for icon in web_manifest.get("icons", []))), "web manifest needs Orbit logo")
check(bool(assetlinks and assetlinks[0].get("target", {}).get("package_name") == "app.orbit.social"), "Digital Asset Links package id mismatch")
if assetlinks:
    fps = assetlinks[0].get("target", {}).get("sha256_cert_fingerprints", [])
    check(bool(fps and "REPLACE_WITH_" in fps[0]), "template should retain explicit signing fingerprint placeholder until Play signing is known")

html = (ROOT / "website-updates" / "index.html").read_text()
check('rel="manifest" href="./manifest.webmanifest"' in html, "website update page doesn't link manifest")
check("/.well-known/assetlinks.json" in (ROOT / "README.md").read_text(), "README missing asset links publishing instructions")
check((ROOT / ".github" / "workflows" / "android-build.yml").exists(), "build workflow missing")

if errors:
    print("PREFLIGHT FAILED")
    for error in errors:
        print(" -", error)
    sys.exit(1)
print("PREFLIGHT PASSED")
print(f"XML files parsed: {len(xml_files)}")
print("Web manifest and Digital Asset Links template: valid JSON")
print("Target SDK: 36; package: app.orbit.social")
print("Note: this is static validation only; Android compilation/device testing was not available here.")
