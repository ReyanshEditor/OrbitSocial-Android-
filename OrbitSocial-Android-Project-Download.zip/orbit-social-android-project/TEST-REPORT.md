# Orbit Social Android packaging — local preflight report

Date: 2026-10-23

## Checks performed

- Android manifest and all Android resource XML files parse as well-formed XML.
- Gradle/Kotlin configuration files are present and declare compileSdk/targetSdk 36.
- Web app manifest parses as JSON and declares standalone display plus Orbit icons.
- Digital Asset Links template parses as JSON and uses the matching Android application ID.
- Launch URL in Android resources matches the deployed Orbit Social URL.
- Custom Orbit SVG and PNG logo assets exist; Android adaptive launcher icons now use a purple gradient background and orbit-star foreground.
- The source preflight script passes.
- The final project ZIP passes CRC/integrity verification.

## Not yet verified

- Gradle compilation, Android SDK lint, APK installation, emulator/device execution, or Google sign-in/backend flows inside Android.
- A signed `.apk` or `.aab` build; this environment has no Android SDK or Gradle and cannot resolve package hosts.
- Full-screen TWA verification: the site's manifest and Digital Asset Links file still need to be published, and the asset links need the actual Play App Signing SHA-256 certificate fingerprint.

These are not reported as passing tests. The included GitHub Actions workflow can build a debug APK when the project is pushed to a repository and the workflow is run.
